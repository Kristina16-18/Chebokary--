import pygame
import time
import sqlite3
import main, menu_pause, const

start_input_for_name = False
start_input_for_password = False
user_name = ''
user_password = ''
text_tick_name = -40
text_tick_password = -40


class User:
    def __init__(self):
        self.name = ''
        self.password = ''
        self.score_1 = 0
        self.score_2 = 0
        self.score_3 = 0
        self.score_4 = 0
        self.score_5 = 0


user = User()

def name_login():
    global start_input_for_name, start_input_for_password, user_name, user_password, text_tick_name, text_tick_password
    input_rect = pygame.Rect(325, 200, 150, 35)
    pygame.draw.rect(const.menu_display, (255, 255, 255), input_rect)
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    # Захват окна
    if input_rect.collidepoint(mouse[0], mouse[1]) and click[0]:
        start_input_for_name = True
        text_tick_name = 30
        
        start_input_for_password = False
        text_tick_password = -40
    
    # Добавление буквы
    if start_input_for_name:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                text_tick_name = 30
                if event.key == pygame.K_BACKSPACE:
                    user_name = user_name[:-1]
                else:
                    if len(user_name) < 15:
                        user_name += event.unicode

    # Печать
    if len(user_name) > 0 or text_tick_name > 0:
        smalltext = pygame.font.Font("freesansbold.ttf", 20)
        textsurf = smalltext.render(user_name + '|' * (text_tick_name > 0), True, const.BLACK)
        textrect = textsurf.get_rect()
        textrect.x, textrect.y = input_rect.x + 10, input_rect.y + 7.5
        const.menu_display.blit(textsurf, textrect)

    text_tick_name -= 1
    if text_tick_name == -30:
        text_tick_name = 30

    if const.login_pressed:
        try:
            con = sqlite3.connect("users.sqlite")
            cur = con.cursor()
            names = cur.execute('SELECT name FROM data').fetchall()
            if user_name not in names:
                raise Exception
        except Exception:
            pass


def password_login():
    global start_input_for_name, start_input_for_password, user_name, user_password, text_tick_name, text_tick_password, user
    input_rect = pygame.Rect(325, 240, 150, 35)
    pygame.draw.rect(const.menu_display, (255, 255, 255), input_rect)
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    # Захват окна
    if input_rect.collidepoint(mouse[0], mouse[1]) and click[0]:
        start_input_for_password = True
        text_tick_password = 30
        
        start_input_for_name = False
        text_tick_name = -40
    
    # Добавление буквы
    if start_input_for_password:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                text_tick_password = 30
                if event.key == pygame.K_BACKSPACE:
                    user_password = user_password[:-1]
                else:
                    if len(user_password) < 15:
                        user_password += event.unicode
    
    # Печать
    if len(user_password) > 0 or text_tick_password > 0:
        smalltext = pygame.font.Font("freesansbold.ttf", 20)
        textsurf = smalltext.render('*' * len(user_password) + '|' * (text_tick_password > 0), True, const.BLACK)
        textrect = textsurf.get_rect()
        textrect.x, textrect.y = input_rect.x + 10, input_rect.y + 7.5
        const.menu_display.blit(textsurf, textrect)

    text_tick_password -= 1
    if text_tick_password == -30:
        text_tick_password = 30

    if const.login_pressed:
        try:
            con = sqlite3.connect("users.sqlite")
            cur = con.cursor()
            password = cur.execute('''SELECT password FROM data
            WHERE name = ?''', (user_name)).fetchall()
            if user_password != password:
                raise Exception
            else:
                user.score_1, user.score_2, user.score_3, user.score_4, user.score_5 = cur.execute('''SELECT score_1, score_2, score_3, score_4, score_5 FROM data
            WHERE name = ?''', (user_name)).fetchall()
        except Exception:
            pass
